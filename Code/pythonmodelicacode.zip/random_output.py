def random_output(input):
    import numpy as np
    return np.random.randint(100)
